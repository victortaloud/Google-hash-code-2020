FILEPATHS = {
    1 : '/data/testA.txt',
    2 : '/data/testB.txt'
}