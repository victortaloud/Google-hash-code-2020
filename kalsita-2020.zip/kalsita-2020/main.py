import sys
import datetime
import os
import os.path
import logging 
from config import *

from prompt_toolkit import prompt
import time
import datetime


logging.getLogger().setLevel(logging.INFO)

# from photo import Photo
# from slide import Slide
# from slideshow import Slideshow
# from algo import *

def parse_input(filename):

    f = open(filename)

    # Parse input file 
    # list_photos = []
    
    # for (counter, line) in enumerate(f):
    #     line_splitted = line.split()

    #     if counter == 0:
    #         nb_photos = int(line_splitted[0]) # to check parsing is correct

    #     else:
    #         photo_item = Photo(id=counter-1, orientation=line_splitted[0], number_tags=int(line_splitted[1]), tags=line_splitted[2:])
    #         list_photos.append(photo_item)

    #         del photo_item

    f.close()
    logging.info('File closed')

    # assert('Missing data:', len(list_photos) == nb_photos)

    return list_photos


def solver_v0(list_photos):
    slides = []

    for photo in list_photos:
        if photo.orientation == 'V':
            continue
        slides.append(Slide([photo]))

    slideshow = Slideshow(slides)

    return slideshow

def solver_v1(list_photos):
    print("lancement du glouton")
    #algo = Algo(list_photos)
    
    #return algo.glouton()
    return 0



def write_submission(solution, submission_name):
    # inputs = solution, submission_name

    f = open(submission_name, "w")

    # slides = slideshow.slides
    

    # f.write(str(len(slides)) + '\n')

    # for slide in slides[:-1]:
    #     line = [str(photo.id) for photo in slide.photos]
    #     line_str = ' '.join(line) + '\n'
    #     f.write(line_str)

    # # last line without \n
    # last_slide = slides[-1]
    # last_line = [str(photo.id) for photo in last_slide.photos]
    # last_line_str = ' '.join(last_line)
    last_line_str = solution
    f.write(last_line_str)
    f.close()


def get_file_to_process(file_ids):
    file_ids_int = [int(idx) for idx in file_ids.split(' ')]
    try:
        filepaths = [FILEPATHS[idx] for idx in  file_ids_int]
    except:
        raise Exception('file ids typed are not in config var FILEPATHS')
    return filepaths


def run(filenames):

    # create a folder with all the files for this submission
    path = './submissions/' + datetime.datetime.now().isoformat()
    os.mkdir(path)
    
    for filename in filenames:
        #logging.info(f'{filename} processing started')

        # PARSING FUNCTIONS 
        # list_photos = parse_input(filename)
        
        now = datetime.datetime.now()
        #logging.info(f'{filename} parsed - {now}')
        start_time = time.time()

        # solver
        # solution = solver_v1(list_photos)
        #logging.info(f'{filename} solved')
        time.sleep(3)
        end_time = time.time()
        computing_time = datetime.timedelta(seconds=(end_time - start_time)) 

        # get score
        score = 10
        logging.info(f'{filename} SCORE = {score} - SOLVING TIME = {computing_time}')

        # create submission name and write output file
        submission_name = path + '/Kalsita_' + filename.split('/')[-1]

        solution = 'This is a test solution'
        
        write_submission(solution, submission_name)
        logging.info(f'{filename} submission written')


if __name__ == "__main__":

    prompt_files_idx = prompt('Enter file ids to process (ex: 2 1 3): ')
    filenames = get_file_to_process(prompt_files_idx)
    run(filenames)


